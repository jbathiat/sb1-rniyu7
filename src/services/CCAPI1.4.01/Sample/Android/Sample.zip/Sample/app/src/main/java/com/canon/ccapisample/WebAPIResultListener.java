package com.canon.ccapisample;

interface WebAPIResultListener {
    void onWebAPIResult(WebAPIResultDataSet result);
}
