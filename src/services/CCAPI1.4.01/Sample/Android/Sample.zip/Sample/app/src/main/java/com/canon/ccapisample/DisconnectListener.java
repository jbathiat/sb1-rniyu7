package com.canon.ccapisample;

interface DisconnectListener {
    void onNotifyDisconnect(String message, boolean isDisconnection);
}
