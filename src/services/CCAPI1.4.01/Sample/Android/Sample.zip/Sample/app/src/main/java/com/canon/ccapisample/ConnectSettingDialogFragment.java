package com.canon.ccapisample;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static com.canon.ccapisample.Constants.CCAPI.Field.AUTHENTICATION;
import static com.canon.ccapisample.Constants.CCAPI.Field.CHANNEL;
import static com.canon.ccapisample.Constants.CCAPI.Field.ENCRYPTION;
import static com.canon.ccapisample.Constants.CCAPI.Field.GATEWAY;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPADDRESS;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPADDRESSSET;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV4_GATEWAY;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV4_IPADDRESS;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV4_IPADDRESSSET;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV4_SUBNETMASK;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV6_GATEWAY;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV6_MANUAL_ADDRESS;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV6_MANUAL_SETTING;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV6_PREFIXLENGTH;
import static com.canon.ccapisample.Constants.CCAPI.Field.IPV6_USEIPV6;
import static com.canon.ccapisample.Constants.CCAPI.Field.KEYINDEX;
import static com.canon.ccapisample.Constants.CCAPI.Field.METHOD;
import static com.canon.ccapisample.Constants.CCAPI.Field.PASSWORD;
import static com.canon.ccapisample.Constants.CCAPI.Field.LANTYPE;
import static com.canon.ccapisample.Constants.CCAPI.Field.SSID;
import static com.canon.ccapisample.Constants.CCAPI.Field.SUBNETMASK;
import static com.canon.ccapisample.Constants.CCAPI.Field.WIFI_SETTINGS;
import static com.canon.ccapisample.Constants.CCAPI.Field.CONNECTSETTING;
import static com.canon.ccapisample.Constants.CCAPI.Method.DELETE;
import static com.canon.ccapisample.Constants.CCAPI.Method.GET;
import static com.canon.ccapisample.Constants.CCAPI.Method.PUT;
import static com.canon.ccapisample.Constants.CCAPI.VER100;
import static com.canon.ccapisample.Constants.CCAPI.Value.AES;
import static com.canon.ccapisample.Constants.CCAPI.Value.AUTO;
import static com.canon.ccapisample.Constants.CCAPI.Value.CAMERAAP;
import static com.canon.ccapisample.Constants.CCAPI.Value.DISABLE;
import static com.canon.ccapisample.Constants.CCAPI.Value.ENABLE;
import static com.canon.ccapisample.Constants.CCAPI.Value.INFRASTRUCTURE;
import static com.canon.ccapisample.Constants.CCAPI.Value.MANUAL;
import static com.canon.ccapisample.Constants.CCAPI.Value.NONE;
import static com.canon.ccapisample.Constants.CCAPI.Value.OPEN;
import static com.canon.ccapisample.Constants.CCAPI.Value.SHAREDKEY;
import static com.canon.ccapisample.Constants.CCAPI.Value.TKIPAES;
import static com.canon.ccapisample.Constants.CCAPI.Value.WEP;
import static com.canon.ccapisample.Constants.CCAPI.Value.WPAWPA2PSK;
import static com.canon.ccapisample.Constants.CCAPI.Value.WPAWPA2WPA3PERSONAL;
import static com.canon.ccapisample.Constants.CCAPI.Value.ENHANCEDOPEN;
import static com.canon.ccapisample.Constants.CCAPI.Value.WPAWPA2WPA3ENTERPRISE;
import static com.canon.ccapisample.Constants.CCAPI.Value.WPA3ENTERPRISE192BIT;
import static com.canon.ccapisample.Constants.CCAPI.Value.WPA2WPA3PERSONAL;
import static com.canon.ccapisample.Constants.CCAPI.Value.ETHER;
import static com.canon.ccapisample.Constants.CCAPI.Value.WIFI;



/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ConnectSettingDialogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ConnectSettingDialogFragment extends DialogFragment implements WebAPIResultListener, RadioGroup.OnCheckedChangeListener {
    private static final String TAG = ConnectSettingDialogFragment.class.getSimpleName();
    private static final String API_KEY = "ApiKey";
    private WebAPI mWebAPI;
    private APIDataSet mApiDataSet;

    private final Map<String, Integer> mViewIDMap = new HashMap<String, Integer>() {
        {
            put(LANTYPE, R.id.Connect_LantypeRadio );
            put(SSID, R.id.Connect_SsidEdit );
            put(METHOD, R.id.Connect_MethodRadio );
            put(CHANNEL, R.id.Connect_ChannelSpinner );
            put(AUTHENTICATION, R.id.Connect_AuthenticationRadio );
            put(PASSWORD, R.id.Connect_PasswordEdit );
            put(IPV4_IPADDRESSSET, R.id.Connect_Ipv4_IpaddresssetRadio );
            put(IPV4_IPADDRESS, R.id.Connect_Ipv4_IpaddressEdit );
            put(IPV4_SUBNETMASK, R.id.Connect_Ipv4_SubnetmaskEdit );
            put(IPV4_GATEWAY, R.id.Connect_Ipv4_GatewayEdit );
            put(IPV6_USEIPV6, R.id.Connect_Ipv6_UseIpv6Radio );
            put(IPV6_MANUAL_SETTING, R.id.Connect_Ipv6_Manual_SettingRadio );
            put(IPV6_MANUAL_ADDRESS, R.id.Connect_Ipv6_Manual_AddressEdit );
            put(IPV6_PREFIXLENGTH, R.id.Connect_Ipv6_PrefixLengthEdit );
            put(IPV6_GATEWAY, R.id.Connect_Ipv6_GatewayEdit );
        }
    };

    private final Map<String, Integer> mLantypeRadioIDMap = new HashMap<String, Integer>() {
        {
            put(ETHER, R.id.Connect_EtherRadioButton );
            put(WIFI, R.id.Connect_WifiRadioButton );
        }
    };

    private final Map<String, Integer> mMethodRadioIDMap = new HashMap<String, Integer>() {
        {
            put(INFRASTRUCTURE, R.id.Connect_InfrastructureRadioButton );
            put(CAMERAAP, R.id.Connect_CameraapRadioButton );
        }
    };

    private final Map<String, Integer> mAuthenticationRadioIDMap = new HashMap<String, Integer>() {
        {
            put(OPEN, R.id.Connect_OpenRadioButton );
            put(ENHANCEDOPEN, R.id.Connect_Enhanced_OpenRadioButton );
            put(WPAWPA2WPA3PERSONAL, R.id.Connect_Wpawpa2wpa3personalRadioButton );
            put(WPAWPA2WPA3ENTERPRISE, R.id.Connect_Wpawpa2wpa3enterpriseRadioButton );
            put(WPA3ENTERPRISE192BIT, R.id.Connect_Wpa3enterprise192bitRadioButton );
            put(WPA2WPA3PERSONAL, R.id.Connect_Wpa2wpa3personalRadioButton );
        }
    };

    private final Map<String, Integer> mIpv4_IpaddresssetRadioIDMap = new HashMap<String, Integer>() {
        {
            put(AUTO, R.id.Connect_Ipv4_Ipaddressset_AutoRadioButton );
            put(MANUAL, R.id.Connect_Ipv4_Ipaddressset_ManualRadioButton );
        }
    };

    private final Map<String, Integer> mIpv6_UseIpv6RadioIDMap = new HashMap<String, Integer>() {
        {
            put(ENABLE, R.id.Connect_Ipv6_UseIpv6_EnableRadioButton);
            put(DISABLE, R.id.Connect_Ipv6_UseIpv6_DisableRadioButton);
        }
    };

    private final Map<String, Integer> mIpv6_Manual_SettingRadioIDMap = new HashMap<String, Integer>() {
        {
            put(ENABLE, R.id.Connect_Ipv6_Manual_Setting_EnableRadioButton );
            put(DISABLE, R.id.Connect_Ipv6_Manual_Setting_DisableRadioButton );
        }
    };

    private final Map<String, Map<String, Integer>> mRadioIDMap = new HashMap<String, Map<String, Integer>>(){
        {
            put(LANTYPE, mLantypeRadioIDMap );
            put(METHOD, mMethodRadioIDMap );
            put(AUTHENTICATION, mAuthenticationRadioIDMap );
            put(IPV4_IPADDRESSSET, mIpv4_IpaddresssetRadioIDMap );
            put(IPV6_USEIPV6, mIpv6_UseIpv6RadioIDMap );
            put(IPV6_MANUAL_SETTING, mIpv6_Manual_SettingRadioIDMap );
        }
    };

    public ConnectSettingDialogFragment() {
        // Required empty public constructor
    }

    public static ConnectSettingDialogFragment newInstance(Fragment target, String key) {
        ConnectSettingDialogFragment fragment = new ConnectSettingDialogFragment();
        fragment.setTargetFragment(target, 0);
        Bundle args = new Bundle();
        args.putString(API_KEY, key);
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle arguments) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        mWebAPI = WebAPI.getInstance();
        String apiKey = getArguments().getString(API_KEY);
        mApiDataSet = mWebAPI.getAPIData(apiKey);

        View view = getActivity().getLayoutInflater().inflate(R.layout.fragment_dialog_connect_setting, null);
        LinearLayout layout = view.findViewById(R.id.ConnectSettings);

        // Get current values.
        if (mApiDataSet != null && mApiDataSet.isGetable()) {
            Bundle args = new Bundle();
            String[] params = new String[]{GET, mApiDataSet.getUrl(), null};
            args.putStringArray(Constants.RequestCode.ACT_WEB_API.name(), params);
            mWebAPI.enqueueRequest(new WebAPIQueueDataSet(Constants.RequestCode.ACT_WEB_API, args, this));
        }

        dialog.setTitle(CONNECTSETTING);
        dialog.setView(layout);
        dialog.setPositiveButton("Set", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                setConnectSetting();
            }
        });
        dialog.setNegativeButton("Reset", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                resetConnectSetting();
            }
        });

        RadioGroup lantypeRadio = view.findViewById(R.id.Connect_LantypeRadio);
        lantypeRadio.setOnCheckedChangeListener(this);
        RadioGroup methodRadio = view.findViewById(R.id.Connect_MethodRadio);
        methodRadio.setOnCheckedChangeListener(this);
        RadioGroup authenticationRadio = view.findViewById(R.id.Connect_AuthenticationRadio);
        authenticationRadio.setOnCheckedChangeListener(this);

        return dialog.create();
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
    }

    @Override
    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
        Log.d(TAG, "onCheckedChanged");
        Dialog view = getDialog();
        if(view != null) {
            if(group.getId() == R.id.Connect_LantypeRadio ||
                    group.getId() == R.id.Connect_MethodRadio ||
                    group.getId() == R.id.Connect_AuthenticationRadio ||
                    group.getId() == R.id.Connect_Ipv4_IpaddresssetRadio ||
                    group.getId() == R.id.Connect_Ipv6_UseIpv6Radio ||
                    group.getId() == R.id.Connect_Ipv6_Manual_SettingRadio){
                // Change Visibility of the View in accordance with the current value.
                setViewVisibility(view);

            }
        }
    }

    /**
     * Callback from execute WebAPI
     * @param result HTTP Request result
     */
    @Override
    public void onWebAPIResult(WebAPIResultDataSet result){
        Log.d(TAG, String.format("%s onWebAPIResult", result.getRequestCode()));
        Context context = getActivity();

        // Do nothing, if life cycle of the fragment is finished.
        if(context != null) {
            if (result.isError()) {
                Toast.makeText(context, result.getErrorMsg(), Toast.LENGTH_SHORT).show();
            }
            else {
                switch (result.getRequestCode()) {
                    case ACT_WEB_API:
                        setValue(result.getResponseBody());
                        break;
                    default:
                        break;
                }
            }
        }
        else{
            Log.d(TAG, String.format("%s Activity is Null.", result.getRequestCode()));
        }
    }

    private void setConnectSetting(){
        JSONObject body = new JSONObject();

        for (String name : mViewIDMap.keySet()) {
            try {
                body.put(name, getValue(name));
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, body.toString());

        if (mApiDataSet != null && mApiDataSet.isPutable()) {
            Bundle args = new Bundle();
            String[] params = new String[]{PUT, mApiDataSet.getUrl(), body.toString()};
            args.putStringArray(Constants.RequestCode.ACT_WEB_API.name(), params);

            // Execute the API.
            // The onWebAPIResult() of caller Fragment process the execution result, because the dialog is closed.
            mWebAPI.enqueueRequest(new WebAPIQueueDataSet(Constants.RequestCode.ACT_WEB_API, args, new WebAPIResultListener() {
                @Override
                public void onWebAPIResult(WebAPIResultDataSet result) {
                    if (getTargetFragment() instanceof WebAPIResultListener) {
                        ((WebAPIResultListener) getTargetFragment()).onWebAPIResult(result);
                    }
                }
            }));
        }
    }

    private void resetConnectSetting(){

        // Execute the API.
        // The onWebAPIResult() of caller Fragment process the execution result, because the dialog is closed.
        if (mApiDataSet != null && mApiDataSet.isPutable()) {
            Bundle args = new Bundle();
            String[] params = new String[]{DELETE, mApiDataSet.getUrl(), null};
            args.putStringArray(Constants.RequestCode.ACT_WEB_API.name(), params);

            // Execute the API.
            // The onWebAPIResult() of caller Fragment process the execution result, because the dialog is closed.
            mWebAPI.enqueueRequest(new WebAPIQueueDataSet(Constants.RequestCode.ACT_WEB_API, args, new WebAPIResultListener() {
                @Override
                public void onWebAPIResult(WebAPIResultDataSet result) {
                    if (getTargetFragment() instanceof WebAPIResultListener) {
                        ((WebAPIResultListener) getTargetFragment()).onWebAPIResult(result);
                    }
                }
            }));
        }
    }

    private String getValue(String name){
        String value = "";
        Dialog view = getDialog();

        if(view != null) {
            int id = mViewIDMap.get(name);
            View tempView = view.findViewById(id);

            if (tempView.isShown()) {
                switch (name) {
                    case SSID:
                    case PASSWORD:
                    case IPV4_IPADDRESS:
                    case IPV4_SUBNETMASK:
                    case IPV4_GATEWAY:
                    case IPV6_MANUAL_ADDRESS:
                    case IPV6_PREFIXLENGTH:
                    case IPV6_GATEWAY:
                        EditText editText = (EditText) tempView;
                        value = editText.getText().toString();
                        break;

                    case LANTYPE:
                    case METHOD:
                    case AUTHENTICATION:
                    case IPV4_IPADDRESSSET:
                    case IPV6_USEIPV6:
                    case IPV6_MANUAL_SETTING:

                        RadioGroup radioGroup = (RadioGroup) tempView;
                        int radioID = radioGroup.getCheckedRadioButtonId();

                        for (String key : mRadioIDMap.get(name).keySet()) {
                            if (radioID == mRadioIDMap.get(name).get(key)) {
                                value = key;
                                break;
                            }
                        }
                        break;

                    case CHANNEL:
                        Spinner spinner = (Spinner) tempView;
                        value = spinner.getSelectedItem().toString();
                        break;

                    default:
                        break;
                }
            }
            else {
                value = "";
            }
        }

        return value;
    }

    private void setValue(String responseBody){
        Dialog view = getDialog();

        if(view != null) {
            try {
                JSONObject response = new JSONObject(responseBody);
                Iterator<String> keys = response.keys();

                // Reflect the current value in the View.
                while (keys.hasNext()) {
                    String name = keys.next();
                    String value = response.getString(name);

                    if(mViewIDMap.containsKey(name)){
                        int id = mViewIDMap.get(name);
                        switch (name) {
                            case SSID:
                            case IPADDRESS:
                            case SUBNETMASK:
                            case GATEWAY:
                            case IPV4_IPADDRESS:
                            case IPV4_SUBNETMASK:
                            case IPV4_GATEWAY:
                            case IPV6_MANUAL_ADDRESS:
                            case IPV6_PREFIXLENGTH:
                            case IPV6_GATEWAY:
                                EditText editText = view.findViewById(id);
                                editText.setText(value);
                                break;

                            case LANTYPE:
                            case METHOD:
                            case AUTHENTICATION:
                            case ENCRYPTION:
                            case IPADDRESSSET:
                            case IPV4_IPADDRESSSET:
                            case IPV6_USEIPV6:
                            case IPV6_MANUAL_SETTING:
                                RadioGroup radioGroup = view.findViewById(id);
                                if(mRadioIDMap.containsKey(name)){
                                    for (String key : mRadioIDMap.get(name).keySet()) {
                                        if(key.equals(value)){
                                            radioGroup.check(mRadioIDMap.get(name).get(key));
                                            break;
                                        }
                                    }
                                }
                                break;

                            case CHANNEL:
                            case KEYINDEX:
                                Spinner spinner = view.findViewById(id);
                                for (int i = 0; i < spinner.getCount(); i++){
                                    if (spinner.getItemAtPosition(i).toString().equals(value)){
                                        spinner.setSelection(i);
                                        break;
                                    }
                                }
                                break;

                            default:
                                break;
                        }
                    }
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }

            // Change Visibility of the View in accordance with the current value.
            setViewVisibility(view);

            // Register the OnCheckedChangeListener after reflection of the current value.
            RadioGroup LantypeRadio = view.findViewById(R.id.Connect_LantypeRadio);
            LantypeRadio.setOnCheckedChangeListener(this);
            RadioGroup methodRadio = view.findViewById(R.id.Connect_MethodRadio);
            methodRadio.setOnCheckedChangeListener(this);
            RadioGroup authenticationRadio = view.findViewById(R.id.Connect_AuthenticationRadio);
            authenticationRadio.setOnCheckedChangeListener(this);
            RadioGroup ipv4AddressSetRadio = view.findViewById(R.id.Connect_Ipv4_IpaddresssetRadio);
            ipv4AddressSetRadio.setOnCheckedChangeListener(this);
            RadioGroup UseIpv6Radio = view.findViewById(R.id.Connect_Ipv6_UseIpv6Radio);
            UseIpv6Radio.setOnCheckedChangeListener(this);
            RadioGroup ipv6ManualSettingRadio = view.findViewById(R.id.Connect_Ipv6_Manual_SettingRadio);
            ipv6ManualSettingRadio.setOnCheckedChangeListener(this);
        }
    }

    private void setViewVisibility(Dialog view) {

        RadioGroup lantypeRadio = view.findViewById(R.id.Connect_LantypeRadio);
        RadioGroup methodRadio = view.findViewById(R.id.Connect_MethodRadio);
        RadioGroup authenticationRadio = view.findViewById(R.id.Connect_AuthenticationRadio);

        int lantypeID = lantypeRadio.getCheckedRadioButtonId();
        int methodID = methodRadio.getCheckedRadioButtonId();
        int authenticationID = authenticationRadio.getCheckedRadioButtonId();

        if (lantypeID == R.id.Connect_WifiRadioButton) {
            view.findViewById(R.id.Connect_MethodLayout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.Connect_AuthenticationLayout).setVisibility(View.VISIBLE);
            if (methodID == R.id.Connect_InfrastructureRadioButton) {
                view.findViewById(R.id.Connect_ChannelLayout).setVisibility(View.GONE);
            } else {
                view.findViewById(R.id.Connect_ChannelLayout).setVisibility(View.VISIBLE);
            }
            if( authenticationID == R.id.Connect_OpenRadioButton || authenticationID == R.id.Connect_Enhanced_OpenRadioButton){
                view.findViewById(R.id.Connect_PasswordLayout).setVisibility(View.GONE);
                view.findViewById(R.id.Connect_PasswordEdit).setVisibility(View.GONE);
            }
            else{
                view.findViewById(R.id.Connect_PasswordLayout).setVisibility(View.VISIBLE);
                view.findViewById(R.id.Connect_PasswordEdit).setVisibility(View.VISIBLE);
            }
        } else {
            view.findViewById(R.id.Connect_SsidLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_SsidEdit).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_MethodLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_AuthenticationLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_ChannelLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_PasswordLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_PasswordEdit).setVisibility(View.GONE);
        }

        // Hide unwanted layouts

        RadioGroup ipv4AddressSetRadio = view.findViewById(R.id.Connect_Ipv4_IpaddresssetRadio);
        int ipv4AddressSetID = ipv4AddressSetRadio.getCheckedRadioButtonId();

        if (ipv4AddressSetID == R.id.Connect_Ipv4_Ipaddressset_AutoRadioButton) {
            view.findViewById(R.id.Connect_Ipv4_IpaddressEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv4_SubnetmaskEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv4_GatewayEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv4_IpaddressLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_Ipv4_SubnetmaskLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_Ipv4_GatewayLayout).setVisibility(View.GONE);
        } else {
            view.findViewById(R.id.Connect_Ipv4_IpaddressEdit).setEnabled(true);
            view.findViewById(R.id.Connect_Ipv4_SubnetmaskEdit).setEnabled(true);
            view.findViewById(R.id.Connect_Ipv4_GatewayEdit).setEnabled(true);
            view.findViewById(R.id.Connect_Ipv4_IpaddressLayout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.Connect_Ipv4_SubnetmaskLayout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.Connect_Ipv4_GatewayLayout).setVisibility(View.VISIBLE);
        }

        RadioGroup UseIpv6Radio = view.findViewById(R.id.Connect_Ipv6_UseIpv6Radio);
        int UseIpv6RID = UseIpv6Radio.getCheckedRadioButtonId();

        if (UseIpv6RID == R.id.Connect_Ipv6_UseIpv6_EnableRadioButton) {

            view.findViewById(R.id.Connect_Ipv6_Manual_SettingLayout).setVisibility(View.VISIBLE);

            RadioGroup Ipv6ManualSetting = view.findViewById(R.id.Connect_Ipv6_Manual_SettingRadio);
            int Ipv6ManualSettingRID = Ipv6ManualSetting.getCheckedRadioButtonId();

            if (Ipv6ManualSettingRID == R.id.Connect_Ipv6_Manual_Setting_EnableRadioButton) {
                view.findViewById(R.id.Connect_Ipv6_Manual_AddressEdit).setEnabled(true);
                view.findViewById(R.id.Connect_Ipv6_PrefixLengthEdit).setEnabled(true);
                view.findViewById(R.id.Connect_Ipv6_GatewayEdit).setEnabled(true);
                view.findViewById(R.id.Connect_Ipv6_Manual_AddressLayout).setVisibility(View.VISIBLE);
                view.findViewById(R.id.Connect_Ipv6_PrefixLengthLayout).setVisibility(View.VISIBLE);
                view.findViewById(R.id.Connect_Ipv6_GatewayLayout).setVisibility(View.VISIBLE);
            } else {
                view.findViewById(R.id.Connect_Ipv6_Manual_AddressEdit).setEnabled(false);
                view.findViewById(R.id.Connect_Ipv6_PrefixLengthEdit).setEnabled(false);
                view.findViewById(R.id.Connect_Ipv6_GatewayEdit).setEnabled(false);
                view.findViewById(R.id.Connect_Ipv6_Manual_AddressLayout).setVisibility(View.GONE);
                view.findViewById(R.id.Connect_Ipv6_PrefixLengthLayout).setVisibility(View.GONE);
                view.findViewById(R.id.Connect_Ipv6_GatewayLayout).setVisibility(View.GONE);
            }
        }
        else{
            view.findViewById(R.id.Connect_Ipv6_Manual_AddressEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv6_PrefixLengthEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv6_GatewayEdit).setEnabled(false);
            view.findViewById(R.id.Connect_Ipv6_Manual_SettingLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_Ipv6_Manual_AddressLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_Ipv6_PrefixLengthLayout).setVisibility(View.GONE);
            view.findViewById(R.id.Connect_Ipv6_GatewayLayout).setVisibility(View.GONE);
        }

    }
}
