package com.canon.ccapisample;

interface EventListener {
    void onNotifyEvent(String response);
}
