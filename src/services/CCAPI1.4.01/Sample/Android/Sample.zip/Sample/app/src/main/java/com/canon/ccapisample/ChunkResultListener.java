package com.canon.ccapisample;

interface ChunkResultListener {
    boolean onChunkResult(byte[] bytes);
}
